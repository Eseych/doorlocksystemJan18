<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'rfidattendance');

if(isset($_POST['deletedata']))
{
    $sectionID = $_POST['delete_id'];

    $query = "DELETE FROM section_tbl WHERE sectionID='$sectionID'";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        echo '<script> alert("Data Deleted"); </script>';
        header("Location:manageSections.php");
    }
    else
    {
        echo '<script> alert("Data Not Deleted"); </script>';
    }
}

?>
