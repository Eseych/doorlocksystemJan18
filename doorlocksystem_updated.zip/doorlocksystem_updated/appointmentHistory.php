<?php
include ('connectDB.php');

// select all past appointments from appointment_tbl
$sql = "SELECT * FROM appointment_tbl WHERE date < CURDATE()";
$result = mysqli_query($conn, $sql);

// loop through the past appointments and insert them into the past_appointment_tbl
while($row = mysqli_fetch_assoc($result)) {
    $name = $row['name'];
    $date = $row['date'];
    $timeStart = $row['timeStart'];
    $timeEnd = $row['timeEnd'];
    $reason = $row['reason'];

    $insertPastAppointment = "INSERT INTO past_appointment_tbl (name, date, timeStart, timeEnd, reason)
    VALUES ('$name', '$date', '$timeStart', '$timeEnd', '$reason')";
    mysqli_query($conn, $insertPastAppointment);
}

// delete past appointments from appointment_tbl
$deletePastAppointments = "DELETE FROM appointment_tbl WHERE date < CURDATE()";
mysqli_query($conn, $deletePastAppointments);

?>
