<?php
  include ('connectDB.php');

  // Get the search query from the user
  $search_query = $_POST['search'];

  // Run the query on the database
  $sql = "SELECT * FROM student_tbl WHERE firstName LIKE '%$search_query%' OR lastName LIKE '%$search_query%' OR studentNumber LIKE '%$search_query%' OR sectionID LIKE '%$search_query%' OR orgName LIKE '%$search_query%'";
  $result = mysqli_query($conn, $sql);

  // Check if any results were found
  if (mysqli_num_rows($result) > 0) {
    // Results were found, so display them
    while ($row = mysqli_fetch_assoc($result)) {
      echo $row['firstName'] . " " . $row['lastName'] . "<br>";
    }
  } else {
    // No results were found
    echo "No results found for '" . $search_query . "'";
  }

?>
