<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'rfidattendance');

    if(isset($_POST['updatedata']))
    {
        $sectionID = $_POST['update_id'];
        $sectionName = $_POST['sectionName'];

        $query = "UPDATE section_tbl SET sectionName='$sectionName' WHERE sectionID='$sectionID'  ";
        $query_run = mysqli_query($connection, $query);

        if($query_run)
        {
            echo '<script> alert("Data Updated"); </script>';
            header("Location:manageSections.php");
        }
        else
        {
            echo '<script> alert("Data Not Updated"); </script>';
        }
    }
?>
