<?php
require 'connectDB.php'; // include the connection file to the database

$profID = $_POST['profID']; // retrieve the section ID from the AJAX request

$sql = "SELECT * FROM prof_tbl WHERE profID = '$profID'"; // create a query to select the section details from the database
$result = mysqli_query($conn, $sql); // execute the query
$professor = mysqli_fetch_assoc($result); // retrieve the section details as an associative array

echo json_encode($professor); // return the section details as a JSON object
